package org.example;

import org.example.presentation.views.ManagementView;
import org.example.presentation.controllers.ManagementController;
import javax.swing.*;

/**
 * The {@code Main} class is the entry point of the application.
 * It initializes the main components of the application and makes the
 * management view visible.
 *
 * This class uses the SwingUtilities to ensure that the GUI
 * components are created and updated on the Event Dispatch Thread (EDT).
 */

public class Main {

    /**
     * Starts the application. It creates the management view,
     * makes it visible, and initializes its controller.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            ManagementView managementView = new ManagementView();
            managementView.setVisible(true);
            new ManagementController(managementView);
        });
    }
}
