package org.example.bll;

import org.example.bll.validators.Validator;
import org.example.bll.validators.ValueValidator;
import org.example.dao.BillDAO;
import org.example.dao.ClientDAO;
import org.example.dao.OrderDAO;
import org.example.model.Bill;
import org.example.model.Client;
import org.example.model.Orderr;

import java.util.List;

/**
 * Handles business logic for bill operations, interfacing with various DAOs and validators to ensure
 * data integrity and business rules are maintained.
 */

public class BillBLL {

    private BillDAO billDAO;
    private OrderDAO orderDAO;
    private ClientDAO clientDAO;

    private Validator<Bill> valueValidator;

    public BillBLL() {
        valueValidator = new ValueValidator();

        billDAO = new BillDAO();
        orderDAO = new OrderDAO();
        clientDAO = new ClientDAO();
    }

    public List<Bill> findAllBills() {

        return billDAO.findAll();
    }

    public Bill insertBill(Bill bill) throws Exception {
        Orderr order = orderDAO.findById(bill.idOrder());
        Client client = clientDAO.findById(bill.idClient());
        if (order == null) {
            throw new Exception("Order not found for this bill");
        }
        else if (client == null) {
            throw new Exception("Client not found for this bill");
        }
        else if (!valueValidator.validate(bill)) {
            throw new Exception("Value is not greater than 0");
        }
        return billDAO.insert(bill);
    }
}
