package org.example.bll;

import org.example.bll.validators.EmailValidator;
import org.example.bll.validators.Validator;
import org.example.dao.ClientDAO;
import org.example.model.Client;

import java.util.List;

/**
 * Business Logic Layer class for managing client-related operations.
 * This class handles client validation and CRUD operations, interfacing with the ClientDAO and
 * using an EmailValidator to ensure client data integrity.
 */

public class ClientBLL {

    private ClientDAO clientDAO;
    private Validator<Client> emailValidator;

    public ClientBLL() {
        emailValidator = new EmailValidator();
        clientDAO = new ClientDAO();
    }

    public Client findClientById(int id) throws Exception {
        Client client = clientDAO.findById(id);
        if(client == null) {
            throw new Exception("Client not found");
        }
        return client;
    }

    public List<Client> findAllClients() {
        return clientDAO.findAll();
    }

    public Client insertClient(Client client) throws Exception {
        if(!emailValidator.validate(client)) {
            throw new Exception("Email is not correct");
        }
        return clientDAO.insert(client);
    }

    public Client updateClient(Client client) throws Exception {
        if(!emailValidator.validate(client)) {
            throw new Exception("Email is not correct");
        }
        Client existingClient = clientDAO.findById(client.getId());
        if(existingClient == null) {
            throw new Exception("Cannot update because the client with ID " + client.getId() + " does not exist.");
        }
        return clientDAO.update(client);
    }

    public boolean deleteClient(Client client) throws Exception {
        Client existingClient = clientDAO.findById(client.getId());
        if(existingClient == null) {
            throw new Exception("Cannot delete because the client with ID " + client.getId() + " does not exist.");
        }
        return clientDAO.delete(client);
    }
}
