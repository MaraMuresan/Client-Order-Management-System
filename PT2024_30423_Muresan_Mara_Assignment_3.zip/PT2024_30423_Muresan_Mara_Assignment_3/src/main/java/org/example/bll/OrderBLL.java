package org.example.bll;

import org.example.bll.validators.QuantityValidator;
import org.example.bll.validators.Validator;
import org.example.dao.BillDAO;
import org.example.dao.ClientDAO;
import org.example.dao.OrderDAO;
import org.example.dao.ProductDAO;
import org.example.model.Bill;
import org.example.model.Client;
import org.example.model.Product;
import org.example.model.Orderr;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Handles business logic for order processing, integrating various DAOs for data access and using a quantity validator
 * to ensure orders meet business rules before being processed.
 */

public class OrderBLL {

    private OrderDAO orderDAO;
    private ClientDAO clientDAO;
    private ProductDAO productDAO;
    private BillDAO billDAO;

    private Validator<Orderr> quantityValidator;

    /**
     * Constructs a new OrderBLL, initializing DAOs and a quantity validator.
     */

    public OrderBLL() {
        quantityValidator = new QuantityValidator();

        orderDAO = new OrderDAO();
        clientDAO = new ClientDAO();
        productDAO = new ProductDAO();
        billDAO = new BillDAO();
    }

    public Orderr findOrderById(int id) throws Exception {
        Orderr order = orderDAO.findById(id);
        if(order == null) {
            throw new Exception("Order not found");
        }
        return order;
    }

    /**
     * Retrieves all orders from the database.
     *
     * @return a list of all orders.
     */

    public List<Orderr> findAllOrders() {
        return orderDAO.findAll();
    }

    /**
     * Inserts a new order into the database after validating necessary conditions such as product availability
     * and client existence.
     *
     * @param order the Orderr to be inserted.
     * @return the inserted Orderr.
     * @throws Exception if product or client does not exist, or quantity validation fails.
     */

    public Orderr insertOrder(Orderr order) throws Exception {
        Product product = productDAO.findById(order.getIdProduct());
        Client client = clientDAO.findById(order.getIdClient());
        if (product == null) {
            throw new Exception("Product not found for this order");
        }
        else if (client == null) {
            throw new Exception("Client not found for this order");
        }
        else if (!quantityValidator.validate(order)) {
            throw new Exception("Quantity is not positive");
        }
        else if (order.getQuantity() > product.getStock()) {
           throw new Exception("Order quantity exceeds available stock. Actual stock: " + product.getStock());
        }

        Product newStock = new Product(product.getId(), product.getName(), product.getPrice(), product.getStock() - order.getQuantity());
        productDAO.update(newStock);

        Orderr insertedOrder = orderDAO.insert(order);

        Bill newBill = new Bill(order.getId(), order.getIdClient(), order.getQuantity() * product.getPrice(), LocalDateTime.now());
        billDAO.insert(newBill);
        return insertedOrder;
    }

    public Orderr updateOrder(Orderr order) throws Exception {
        Product product = productDAO.findById(order.getIdProduct());
        Client client = clientDAO.findById(order.getIdClient());
        Orderr existingOrder = orderDAO.findById(order.getId());
        if(existingOrder == null) {
            throw new Exception("Cannot update because the order with ID " + order.getId() + " does not exist.");
        }
        else if (product == null) {
            throw new Exception("Product not found for this order");
        }
        else if (client == null) {
            throw new Exception("Client not found for this order");
        }
        else if (!quantityValidator.validate(order)) {
            throw new Exception("Quantity is not positive");
        }
        else if (order.getQuantity() > product.getStock()) {
            throw new Exception("Order quantity exceeds available stock");
        }
        return orderDAO.update(order);
    }

    public boolean deleteOrder(Orderr order) throws Exception {
        Orderr existingOrder = orderDAO.findById(order.getId());
        if(existingOrder == null) {
            throw new Exception("Cannot delete because the order with ID " + order.getId() + " does not exist.");
        }
        return orderDAO.delete(order);
    }
}
