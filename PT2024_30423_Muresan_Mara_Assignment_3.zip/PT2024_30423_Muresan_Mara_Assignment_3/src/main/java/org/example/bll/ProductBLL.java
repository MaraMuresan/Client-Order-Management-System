package org.example.bll;

import org.example.bll.validators.PriceValidator;
import org.example.bll.validators.StockValidator;
import org.example.bll.validators.Validator;
import org.example.dao.ProductDAO;
import org.example.model.Client;
import org.example.model.Product;

import java.util.ArrayList;
import java.util.List;

/**
 * Business Logic Layer class for managing product operations.
 * This class handles validation and CRUD operations for products, ensuring business rules
 * such as price and stock validity are enforced before database interactions.
 */

public class ProductBLL {

    private ProductDAO productDAO;
    private List<Validator<Product>> validators;

    public ProductBLL() {
        validators = new ArrayList<Validator<Product>>();
        validators.add(new PriceValidator());
        validators.add(new StockValidator());

        productDAO = new ProductDAO();
    }

    public Product findProductById(int id) throws Exception{
        Product product = productDAO.findById(id);
        if(product == null) {
            throw new Exception("Product not found");
        }
        return product;
    }

    public List<Product> findAllProducts() {
        return productDAO.findAll();
    }

    public Product insertProduct(Product product) throws Exception {
        for (Validator<Product> validator : validators) {
            if (!validator.validate(product)) {
                throw new Exception("Product properties are not correct (the price is not strictly positive or the stock is not greater or equal to 0)");
            }
        }
        return productDAO.insert(product);
    }

    public Product updateProduct(Product product) throws Exception {
        Product existingProduct = productDAO.findById(product.getId());
        if(existingProduct == null) {
            throw new Exception("Cannot update because the product with ID " + product.getId() + " does not exist.");
        }
        for (Validator<Product> validator : validators) {
            if (!validator.validate(product)) {
                throw new Exception("Product properties are not correct (the price is not strictly positive or the stock is not greater or equal to 0)");
            }
        }
        return productDAO.update(product);
    }

    public boolean deleteProduct(Product product) throws Exception {
        Product existingProduct = productDAO.findById(product.getId());
        if(existingProduct == null) {
            throw new Exception("Cannot delete because the product with ID " + product.getId() + " does not exist.");
        }
        return productDAO.delete(product);
    }
}
