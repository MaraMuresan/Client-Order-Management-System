package org.example.bll.validators;

import org.example.model.Client;

import java.util.regex.Pattern;

/**
 * Validates the email of a {@link Client} object to ensure it adheres to the standard email format.
 * This validator uses a regular expression to check if the email attribute of a Client object
 * is in a valid format.
 */

public class EmailValidator implements Validator<Client> {
    private static final String EMAIL_PATTERN = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$";
    @Override
    public boolean validate(Client client) {
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        if(!pattern.matcher(client.getEmail()).matches()) {
            return false;
        }
        return true;
    }
}
