package org.example.bll.validators;

import org.example.model.Product;

/**
 * Validates the price of a {@link Product} to ensure it exceeds a specified minimum threshold.
 * This validator is crucial for preventing the entry of incorrect or unreasonable values that could affect business operations.
 */

public class PriceValidator implements Validator<Product>{
    private static final double MIN_PRICE = 0.0;

    @Override
    public boolean validate(Product product) {
        if(product.getPrice() <= MIN_PRICE) {
            return false;
        }
        return true;
    }
}
