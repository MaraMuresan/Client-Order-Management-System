package org.example.bll.validators;

import org.example.model.Orderr;

/**
 * Validates the quantity of an {@link Orderr} to ensure it meets a specified minimum threshold.
 * This validator helps prevent orders with non-positive quantities, which are not permissible
 * in typical business scenarios.
 */

public class QuantityValidator implements Validator<Orderr>{
    private static final int MIN_QUANTITY = 1;

    @Override
    public boolean validate(Orderr order) {
        if(order.getQuantity() < MIN_QUANTITY) {
            return false;
        }
        return true;
    }
}
