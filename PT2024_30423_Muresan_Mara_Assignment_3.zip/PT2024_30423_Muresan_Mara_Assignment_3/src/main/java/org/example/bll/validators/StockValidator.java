package org.example.bll.validators;

import org.example.model.Product;

/**
 * Validates the stock level of a {@link Product} to ensure it is not negative.
 * This validator prevents the system from having products with invalid stock quantities,
 * which could lead to inconsistencies in inventory management.
 */

public class StockValidator implements Validator<Product>{
    private static final double MIN_STOCK = 0;

    @Override
    public boolean validate(Product product) {
        if(product.getStock() < MIN_STOCK) {
            return false;
        }
        return true;
    }
}
