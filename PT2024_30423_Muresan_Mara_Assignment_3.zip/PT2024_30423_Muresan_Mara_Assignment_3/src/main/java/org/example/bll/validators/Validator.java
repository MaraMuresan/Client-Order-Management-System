package org.example.bll.validators;

/**
 * Represents a generic interface for validation operations across various model entities.
 * This interface enforces a consistent validation framework by providing a single validation method
 * that all implementing classes must override.
 *
 * @param <T> the type of object this validator will evaluate. This allows for the creation of type-specific
 *            validators without coupling the validation logic tightly to the model implementation.
 */

public interface Validator<T> {

    public boolean validate(T t);

}
