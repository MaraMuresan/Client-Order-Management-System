package org.example.bll.validators;

import org.example.model.Bill;

/**
 * Validates the monetary value of a {@link Bill} to ensure it is greater than a specified minimum.
 * This validator helps prevent the creation of bills with non-positive values, which are generally
 * considered invalid in most business contexts.
 */

public class ValueValidator implements Validator<Bill>{
    private static final int MIN_VALUE = 0;

    @Override
    public boolean validate(Bill bill) {
        if(bill.value() <= MIN_VALUE) {
            return false;
        }
        return true;
    }
}
