package org.example.dao;
import org.example.connection.ConnectionFactory;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A generic DAO providing basic CRUD operations applied to a database using JDBC and reflection.
 * This class abstracts and encapsulates all direct operations with the database and is meant to be extended
 * by other DAO classes that specify a particular model class.
 *
 * @param <T> the type parameter indicating the class model this DAO is concerned with.
 */

public class AbstractDAO<T> {
    protected static final Logger LOGGER = Logger.getLogger(AbstractDAO.class.getName());

    private final Class<T> type;

    /**
     * Constructor that automatically deduces the class type for generic operations based on the given class.
     */

    public AbstractDAO() {
        this.type = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    /**
     * Generates a SELECT SQL query string based on the specified field to be matched.
     *
     * @param field the column name in the database to match in the WHERE clause.
     * @return a string representing the SQL SELECT query.
     */

    private String createSelectQuery(String field) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        sb.append(" * ");
        sb.append(" FROM ");
        sb.append(type.getSimpleName());
        sb.append(" WHERE " + field + " = ?");
        return sb.toString();
    }

    /**
     * Generates a simple SELECT SQL query string to retrieve all entries of the specified type.
     *
     * @return a string representing the SQL SELECT query.
     */

    private String createSimpleSelectQuery() {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ");
        sb.append(" * ");
        sb.append(" FROM ");
        sb.append(type.getSimpleName());
        return sb.toString();
    }

    /**
     * Generates an INSERT SQL query string to add a new record to the database.
     *
     * @return a string representing the SQL INSERT query.
     */

    private String createInsertQuery() {
        StringBuilder names = new StringBuilder();
        StringBuilder placeholders = new StringBuilder();

        for (Field field : type.getDeclaredFields()) {
            field.setAccessible(true);
            if (!field.getName().equals("id")) {
                names.append(field.getName()).append(",");
                placeholders.append("?,");
            }
        }

        if (names.length() > 0) {
            names.setLength(names.length() - 1);
            placeholders.setLength(placeholders.length() - 1);
        }

        return "INSERT INTO " + type.getSimpleName() + " (" + names + ") VALUES (" + placeholders + ")";
    }

    /**
     * Generates an UPDATE SQL query string to update an existing record in the database.
     *
     * @return a string representing the SQL UPDATE query.
     */

    private String createUpdateQuery() {
        StringBuilder setClause = new StringBuilder();

        for (Field field : type.getDeclaredFields()) {
            field.setAccessible(true);
            if (!field.getName().equals("id")) {
                if(setClause.length() > 0) setClause.append(", ");
                setClause.append(field.getName()).append(" = ?");
            }
        }
        return "UPDATE " + type.getSimpleName() + " SET " + setClause + " WHERE " + "id" + " = ?";
    }

    /**
     * Generates a DELETE SQL query string to remove a record from the database based on its ID.
     *
     * @return a string representing the SQL DELETE query.
     */

    private String createDeleteQuery() {

        return "DELETE FROM " + type.getSimpleName() + " WHERE id = ?";
    }

    /**
     * Retrieves all records of type T from the database.
     *
     * @return a list of all records retrieved, or null if an error occurs.
     */

    public List<T> findAll() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String query = createSimpleSelectQuery();
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            return createObjects(resultSet);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findAll " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Retrieves a record of type T by its ID from the database.
     *
     * @param id the ID of the record to find.
     * @return an instance of type T representing the found record, or null if not found or an error occurs.
     */

    public T findById(int id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String query = createSelectQuery("id");
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            return createObjects(resultSet).get(0);
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, type.getName() + "DAO:findById " + e.getMessage());
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Converts a ResultSet into a list of objects of type T by using reflection.
     *
     * @param resultSet the ResultSet to be converted.
     * @return a list of objects of type T, or an empty list if conversion fails.
     */

    private List<T> createObjects(ResultSet resultSet) {
        List<T> list = new ArrayList<T>();
        Constructor[] ctors = type.getDeclaredConstructors();
        Constructor ctor = null;
        for (int i = 0; i < ctors.length; i++) {
            ctor = ctors[i];
            if (ctor.getGenericParameterTypes().length == 0)
                break;
        }
        try {
            while (resultSet.next()) {
                ctor.setAccessible(true);
                T instance = (T)ctor.newInstance();
                for (Field field : type.getDeclaredFields()) {
                    String fieldName = field.getName();
                    Object value = resultSet.getObject(fieldName);
                    PropertyDescriptor propertyDescriptor = new PropertyDescriptor(fieldName, type);
                    Method method = propertyDescriptor.getWriteMethod();
                    method.invoke(instance, value);
                }
                list.add(instance);
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IntrospectionException e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Inserts a new entity of type T into the database. This method prepares an INSERT SQL query
     * by dynamically constructing the field names and placeholders based on the fields of the class T,
     * excluding the 'id' field which is typically auto-generated by the database.
     *
     * @param t the entity of type T to be inserted into the database.
     * @return the same entity if the insertion is successful with the 'id' field updated to the value
     *         generated by the database; null if the insertion fails.
     */

    public T insert(T t) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String query = createInsertQuery();
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            int index = 1;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                if (!field.getName().equals("id")) {
                    statement.setObject(index++, field.get(t));
                }
            }

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                resultSet = statement.getGeneratedKeys();
                if (resultSet.next()) {
                    int generatedId = resultSet.getInt(1);
                    Field idField = type.getDeclaredField("id");
                    idField.setAccessible(true);
                    idField.set(t, generatedId);
                }
            }
            return t;
        } catch (SQLException | IllegalAccessException | NoSuchFieldException e) {
            LOGGER.log(Level.SEVERE, "Error executing insertDAO: " + e.getMessage());
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Updates an existing entity of type T in the database. This method prepares an UPDATE SQL query
     * by dynamically constructing the 'SET' clause based on the fields of the class T,
     * using all fields except 'id', which is used in the WHERE clause to identify the record to update.
     *
     * @param t the entity of type T to be updated.
     * @return the updated entity if the update operation is successful; null if the update fails.
     */

    public T update(T t) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        String query = createUpdateQuery();
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);

            int index = 1;
            Field idField = null;

            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                if (field.getName().equals("id")) {
                    idField = field;
                }
                else {
                    statement.setObject(index++, field.get(t));
                }
            }

            if (idField == null) {
                throw new RuntimeException("No ID field found in object " + type.getName());
            }

            statement.setObject(index, idField.get(t));

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected == 0) {
                return null;
            }
            return t;
        } catch (SQLException | IllegalAccessException e) {
            LOGGER.log(Level.SEVERE, "Error executing updateDAO: " + e.getMessage());
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(resultSet);
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return null;
    }

    /**
     * Deletes an entity of type T from the database based on its 'id' field.
     *
     * @param t the entity to be deleted.
     * @return true if the deletion was successful; false otherwise.
     */

    public boolean delete(T t) {
        Connection connection = null;
        PreparedStatement statement = null;
        String query = createDeleteQuery();
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.prepareStatement(query);

            Field idField = null;
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                if (field.getName().equals("id")) {
                    idField = field;
                    break;
                }
            }

            if (idField == null) {
                throw new RuntimeException("No ID field found in object " + type.getName());
            }

            statement.setObject(1, idField.get(t));

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException | IllegalAccessException e) {
            LOGGER.log(Level.SEVERE, "Error executing deleteDAO: " + e.getMessage());
            e.printStackTrace();
        } finally {
            ConnectionFactory.close(statement);
            ConnectionFactory.close(connection);
        }
        return false;
    }
}
