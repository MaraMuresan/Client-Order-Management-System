package org.example.dao;

import org.example.connection.ConnectionFactory;
import org.example.model.Bill;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Data Access Object for managing {@link Bill} entities in the database.
 * Provides methods to perform CRUD operations on bills, utilizing JDBC for database connectivity.
 */

public class BillDAO {
    protected static final Logger LOGGER = Logger.getLogger(BillDAO.class.getName());

    /**
     * Creates a list of {@link Bill} objects from a {@link ResultSet}.
     *
     * @param resultSet the ResultSet to process.
     * @return a list of {@link Bill} objects.
     */

    private List<Bill> createObject(ResultSet resultSet) {
        List<Bill> bills = new ArrayList<>();
        try {
            while (resultSet.next()) {
                Bill bill = new Bill(
                        resultSet.getInt("idOrder"),
                        resultSet.getInt("idClient"),
                        resultSet.getDouble("value"),
                        resultSet.getTimestamp("dateTime").toLocalDateTime()
                );
                bills.add(bill);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating bills from ResultSet: " + e.getMessage(), e);
        }
        return bills;
    }

    /**
     * Retrieves all bills from the database.
     *
     * @return a list of all {@link Bill} records from the database, or an empty list if an error occurs.
     */

    public List<Bill> findAll() {
        String query = "SELECT * FROM bill";
        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            return createObject(resultSet);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error retrieving all bills: " + e.getMessage(), e);
            return new ArrayList<>();
        }
    }

    /**
     * Inserts a new bill into the database and returns the bill with its database-generated ID.
     *
     * @param bill the {@link Bill} to insert.
     * @return the inserted {@link Bill} with its ID, or null if the insertion fails.
     */

    public Bill insert(Bill bill) {
        String query = "INSERT INTO bill (idOrder, idClient, value, dateTime) VALUES (?, ?, ?, ?)";
        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            statement.setInt(1, bill.idOrder());
            statement.setInt(2, bill.idClient());
            statement.setDouble(3, bill.value());
            statement.setTimestamp(4, Timestamp.valueOf(bill.dateTime()));
            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return new Bill(bill.idOrder(), bill.idClient(), bill.value(), bill.dateTime());
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error inserting bill: " + e.getMessage(), e);
        }
        return null;
    }
}
