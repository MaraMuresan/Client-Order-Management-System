package org.example.dao;

import org.example.model.Client;

import java.util.List;
import java.util.logging.Logger;

/**
 * Data Access Object (DAO) class for managing {@link Client} entities.
 * This class extends {@link AbstractDAO} and provides CRUD operations specifically for {@link Client} objects.
 * It leverages the generic DAO framework to perform database operations.
 */

public class ClientDAO extends AbstractDAO<Client>{

    // uses basic CRUD methods from superclass

    private static final Logger LOGGER = Logger.getLogger(ClientDAO.class.getName());
    public ClientDAO() {
        super();
    }

    @Override
    public Client findById(int id) {
        return super.findById(id);
    }

    @Override
    public List<Client> findAll() {
        return super.findAll();
    }

    @Override
    public Client insert(Client client) {
        return super.insert(client);
    }

    @Override
    public Client update(Client client) {
        return super.update(client);
    }

    @Override
    public boolean delete(Client client) {
        return super.delete(client);
    }
}
