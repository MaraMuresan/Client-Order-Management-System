package org.example.dao;

import org.example.model.Orderr;

import java.util.List;
import java.util.logging.Logger;

/**
 * Data Access Object (DAO) class for managing {@link Orderr} entities.
 * This class extends {@link AbstractDAO} and is tailored to provide CRUD operations specifically for {@link Orderr} objects.
 * It uses the generic DAO framework established in {@link AbstractDAO} to interact with the database.
 */

public class OrderDAO extends AbstractDAO<Orderr>{

    // uses basic CRUD methods from superclass

    private static final Logger LOGGER = Logger.getLogger(OrderDAO.class.getName());
    public OrderDAO() {
        super();
    }

    @Override
    public Orderr findById(int id) {
        return super.findById(id);
    }

    @Override
    public List<Orderr> findAll() {
        return super.findAll();
    }

    @Override
    public Orderr insert(Orderr order) {
        return super.insert(order);
    }

    @Override
    public Orderr update(Orderr order) {
        return super.update(order);
    }

    @Override
    public boolean delete(Orderr order) {
        return super.delete(order);
    }
}
