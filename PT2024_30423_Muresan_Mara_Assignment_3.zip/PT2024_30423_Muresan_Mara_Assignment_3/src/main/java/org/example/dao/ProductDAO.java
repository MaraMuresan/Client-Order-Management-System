package org.example.dao;

import org.example.model.Product;

import java.util.List;
import java.util.logging.Logger;

/**
 * Data Access Object (DAO) class for managing {@link Product} entities.
 * This class extends {@link AbstractDAO} and leverages the generic CRUD operations
 * defined in the superclass to handle database interactions for products.
 */

public class ProductDAO extends AbstractDAO<Product>{

    // uses basic CRUD methods from superclass

    private static final Logger LOGGER = Logger.getLogger(ProductDAO.class.getName());
    public ProductDAO() {
        super();
    }

    @Override
    public Product findById(int id) {
        return super.findById(id);
    }

    @Override
    public List<Product> findAll() {
        return super.findAll();
}

    @Override
    public Product insert(Product product) {
        return super.insert(product);
    }

    @Override
    public Product update(Product product) {
        return super.update(product);
    }

    @Override
    public boolean delete(Product product) {
        return super.delete(product);
    }
}
