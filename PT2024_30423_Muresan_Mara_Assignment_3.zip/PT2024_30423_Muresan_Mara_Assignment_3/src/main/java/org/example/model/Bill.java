package org.example.model;
import java.time.LocalDateTime;

/**
 * Represents a bill record associated with a specific order and client.
 * This record stores the order ID, client ID, the bill's monetary value, and the date-time when the bill was issued.
 * The value of the bill must not be negative.
 *
 * @param idOrder The unique identifier of the order associated with this bill.
 * @param idClient The unique identifier of the client associated with this bill.
 * @param value The financial amount of the bill; must be non-negative.
 * @param dateTime The date and time when the bill was generated.
 */

public record Bill(int idOrder,
                   int idClient,
                   double value,
                   LocalDateTime dateTime) {
    public Bill {
        if (value < 0) {
            throw new IllegalArgumentException("Bill value cannot be negative.");
        }
    }

}