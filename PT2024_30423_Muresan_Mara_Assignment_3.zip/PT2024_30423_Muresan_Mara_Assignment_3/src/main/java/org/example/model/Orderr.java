package org.example.model;

/**
 * Represents an order in the system, detailing the client and product associated with the order,
 * as well as the quantity of the product ordered.
 * This class encapsulates the necessary information to track an order's fulfillment.
 */

public class Orderr {

    private int id;
    private int idClient;
    private int idProduct;
    private int quantity;

    public Orderr() {

    }

    public Orderr(int id, int idClient, int idProduct, int quantity) {
        this.id = id;
        this.idClient = idClient;
        this.idProduct = idProduct;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdClient() {
        return idClient;
    }

    public void setIdClient(int idClient) {
        this.idClient = idClient;
    }

    public int getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(int idProduct) {
        this.idProduct = idProduct;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Order {" +
                "idOrder = " + id +
                ", idClient = " + idClient +
                ", idProduct = " + idProduct +
                ", quantity = " + quantity +
                '}';
    }
}
