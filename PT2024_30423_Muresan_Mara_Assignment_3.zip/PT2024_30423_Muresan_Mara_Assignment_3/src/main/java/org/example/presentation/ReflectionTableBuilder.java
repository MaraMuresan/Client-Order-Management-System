package org.example.presentation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Vector;

/**
 * The {@code ReflectionTableBuilder} class provides functionality to dynamically generate a {@link JTable}
 * from a list of objects using reflection to extract field values as table columns.
 * <p>
 * This utility class uses Java reflection to inspect the fields of the first object in the list
 * and uses those fields as the column names for the table. Each subsequent object in the list populates
 * a row in the table with values corresponding to these fields.
 */

public class ReflectionTableBuilder {

    /**
     * Creates a {@link JTable} using the list of objects where each object's fields represent
     * a column in the table. The fields of the objects are accessed via reflection and added as rows
     * in the table model.
     *
     * @param <T> the type parameter of the list, defining the type of objects to be used to populate the table
     * @param objects the list of objects to convert into a table format. If the list is empty or null,
     *                an empty table is returned.
     * @return a {@link JTable} generated from the provided objects, with each field of an object as a column
     * @throws IllegalAccessException if a field is not accessible, its value in the row will be set to {@code null}
     */

    public static <T> JTable createTableFromObjects(List<T> objects) {
        if (objects == null || objects.isEmpty()) {
            return new JTable(new DefaultTableModel());
        }

        DefaultTableModel model = new DefaultTableModel();
        Vector<String> columnNames = new Vector<>();

        Field[] fields = objects.get(0).getClass().getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);
            columnNames.add(field.getName());
        }
        model.setColumnIdentifiers(columnNames);

        for (T obj : objects) {
            Vector<Object> row = new Vector<>();
            for (Field field : fields) {
                try {
                    row.add(field.get(obj));
                } catch (IllegalAccessException e) {
                    row.add(null);
                }
            }
            model.addRow(row);
        }

        return new JTable(model);
    }
}
