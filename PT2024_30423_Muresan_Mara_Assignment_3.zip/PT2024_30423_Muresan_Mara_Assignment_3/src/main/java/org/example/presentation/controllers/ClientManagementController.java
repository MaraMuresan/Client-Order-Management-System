package org.example.presentation.controllers;

import org.example.bll.ClientBLL;
import org.example.model.Client;
import org.example.presentation.views.ManagementView;
import org.example.presentation.views.ClientManagementView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * The {@code ClientManagementController} class handles the interaction between the {@link ClientManagementView}
 * and the underlying business logic via {@link ClientBLL}. It manages the client operations such as adding, editing,
 * and deleting clients, as well as navigating back to the main management menu.
 */

public class ClientManagementController {
    private ClientManagementView clientManagementView;
    private ManagementView managementView;

    public ClientManagementController(ClientManagementView clientManagementView, ManagementView managementView) {
        this.clientManagementView = clientManagementView;
        this.managementView = managementView;
        addListeners();
    }

    private void addListeners() {
        clientManagementView.getAddButton().addActionListener(e ->addClient());
        clientManagementView.getEditButton().addActionListener(e ->editClient());
        clientManagementView.getDeleteButton().addActionListener(e ->deleteClient());
        clientManagementView.getBackButton().addActionListener(e ->navigateBack());
    }

    public void navigateBack() {
        clientManagementView.setVisible(false);
        managementView.setVisible(true);
    }

    private void addClient() {
        String name = clientManagementView.nameTextField.getText();
        String address = clientManagementView.addressTextField.getText();
        String email = clientManagementView.emailTextField.getText();

        if (name.isEmpty() || address.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(clientManagementView, "All fields must be filled", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Client client = new Client(0, name, address, email);
            ClientBLL clientBLL = new ClientBLL();
            clientBLL.insertClient(client);
            clientManagementView.refreshClientTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(clientManagementView, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editClient() {
        int selectedRow = clientManagementView.getClientTable().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(clientManagementView, "Please select a client to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        DefaultTableModel model = (DefaultTableModel) clientManagementView.getClientTable().getModel();
        int clientId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());

        try {
            ClientBLL clientBLL = new ClientBLL();
            Client existingClient = clientBLL.findClientById(clientId);

            String name = clientManagementView.nameTextField.getText();
            String address = clientManagementView.addressTextField.getText();
            String email = clientManagementView.emailTextField.getText();

            if (name.isEmpty() || address.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(clientManagementView, "All fields must be filled", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (name != null && address != null && email != null) {
                existingClient.setName(name);
                existingClient.setAddress(address);
                existingClient.setEmail(email);
                clientBLL.updateClient(existingClient);
                clientManagementView.refreshClientTable();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(clientManagementView, "Failed to update client: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteClient() {
        int selectedRow = clientManagementView.getClientTable().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(clientManagementView, "Please select a client to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        DefaultTableModel model = (DefaultTableModel) clientManagementView.getClientTable().getModel();
        int clientId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());

        int confirm = JOptionPane.showConfirmDialog(clientManagementView, "Are you sure you want to delete this client?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                ClientBLL clientBLL = new ClientBLL();
                clientBLL.deleteClient(new Client(clientId, "", "", ""));
                clientManagementView.refreshClientTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(clientManagementView, "Failed to delete client: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}

