package org.example.presentation.controllers;

import org.example.bll.BillBLL;
import org.example.bll.ClientBLL;
import org.example.bll.OrderBLL;
import org.example.bll.ProductBLL;
import org.example.model.Bill;
import org.example.model.Client;
import org.example.model.Orderr;
import org.example.model.Product;
import org.example.presentation.views.ManagementView;
import org.example.presentation.views.ClientManagementView;
import org.example.presentation.views.ProductManagementView;
import org.example.presentation.views.OrderManagementView;
import org.example.presentation.views.BillsManagementView;

import javax.swing.*;
import java.util.List;

/**
 * The {@code ManagementController} class handles navigation between different management views
 * from the main management dashboard. It facilitates the transitions to client, product, order, and bills management.
 */

public class ManagementController {

    private ManagementView managementView;

    public ManagementController(ManagementView managementView) {
        this.managementView = managementView;
        addListeners();
    }

    private void addListeners() {
        managementView.getClientManagementButton().addActionListener(e -> navigateToClientManagement());
        managementView.getProductManagementButton().addActionListener(e -> navigateToProductManagement());
        managementView.getOrderManagementButton().addActionListener(e -> navigateToOrderManagement());
    }

    public void navigateToClientManagement() {
        SwingUtilities.invokeLater(() -> {
            ClientBLL clientBLL = new ClientBLL();
            List<Client> clients = clientBLL.findAllClients();
            ClientManagementView clientManagementView = new ClientManagementView(clients);
            clientManagementView.setVisible(true);
            new ClientManagementController(clientManagementView, managementView);
            managementView.setVisible(false);
        });
    }

    public void navigateToProductManagement() {
        SwingUtilities.invokeLater(() -> {
            ProductBLL productBLL = new ProductBLL();
            List<Product> products = productBLL.findAllProducts();
            ProductManagementView productManagementView = new ProductManagementView(products);
            productManagementView.setVisible(true);
            new ProductManagementController(productManagementView, managementView);
            managementView.setVisible(false);
        });
    }

    public void navigateToOrderManagement() {
        SwingUtilities.invokeLater(() -> {
            OrderBLL orderBLL = new OrderBLL();
            List<Orderr> orders = orderBLL.findAllOrders();
            BillBLL billBLL = new BillBLL();
            List<Bill> bills = billBLL.findAllBills();
            ClientBLL clientBLL = new ClientBLL();
            List<Client> clients = clientBLL.findAllClients();
            ProductBLL productBLL = new ProductBLL();
            List<Product> products = productBLL.findAllProducts();
            OrderManagementView orderManagementView = new OrderManagementView(orders, clients, products);
            orderManagementView.setVisible(true);
            BillsManagementView billsManagementView = new BillsManagementView(bills);
            new OrderManagementController(orderManagementView, managementView, billsManagementView);
            managementView.setVisible(false);
        });
    }
}

