package org.example.presentation.controllers;

import org.example.bll.OrderBLL;
import org.example.model.Orderr;
import org.example.presentation.views.BillsManagementView;
import org.example.presentation.views.ManagementView;
import org.example.presentation.views.OrderManagementView;

import javax.swing.*;

/**
 * The {@code OrderManagementController} class handles the interactions between the {@link OrderManagementView}
 * and the business logic for order processing. This controller is responsible for placing orders, navigating
 * back to the main management view, and updating the order and bills tables upon successful order placement.
 */

public class OrderManagementController {
    private OrderManagementView orderManagementView;
    private BillsManagementView billsManagementView;
    private ManagementView managementView;

    public OrderManagementController(OrderManagementView orderManagementView, ManagementView managementView, BillsManagementView billsManagementView) {
        this.orderManagementView = orderManagementView;
        this.billsManagementView = billsManagementView;
        this.managementView = managementView;
        addListeners();
    }

    private void addListeners() {
        orderManagementView.getPlaceOrderButton().addActionListener(e ->placeOrder());
        orderManagementView.getBackButton().addActionListener(e ->navigateBack());
    }

    public void navigateBack() {
        orderManagementView.setVisible(false);
        managementView.setVisible(true);
    }

    private void placeOrder() {
        String selectedItem1 = (String) orderManagementView.clientComboBox.getSelectedItem();
        String idClientText = null;
        if (selectedItem1 != null) {
            String[] parts = selectedItem1.split(" - ");
            idClientText = parts[0];
        }
        String selectedItem2 = (String) orderManagementView.productComboBox.getSelectedItem();
        String idProductText = null;
        if (selectedItem2 != null) {
            String[] parts = selectedItem2.split(" - ");
            idProductText = parts[0];
        }
        String quantityText = orderManagementView.quantityTextField.getText();

        if (idClientText.isEmpty() || idProductText.isEmpty() || quantityText.isEmpty()) {
            JOptionPane.showMessageDialog(orderManagementView, "All fields must be filled", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int idClient = Integer.parseInt(idClientText);
        int idProduct = Integer.parseInt(idProductText);
        int quantity = Integer.parseInt(quantityText);

        try {
            Orderr order = new Orderr(0, idClient, idProduct, quantity);
            OrderBLL orderBLL = new OrderBLL();
            orderBLL.insertOrder(order);
            orderManagementView.refreshOrderTable();
            billsManagementView.refreshBillsTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(orderManagementView, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

