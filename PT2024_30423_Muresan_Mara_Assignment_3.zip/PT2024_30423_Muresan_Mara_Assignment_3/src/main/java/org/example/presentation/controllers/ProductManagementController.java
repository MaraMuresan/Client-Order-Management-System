package org.example.presentation.controllers;

import org.example.bll.ProductBLL;
import org.example.model.Product;
import org.example.presentation.views.ManagementView;
import org.example.presentation.views.ProductManagementView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * The {@code ProductManagementController} class handles interactions between the {@link ProductManagementView}
 * and the business logic layer represented by {@link ProductBLL}. It manages product operations such as adding,
 * editing, deleting products, and navigating back to the main management view.
 */

public class ProductManagementController {
    private ProductManagementView productManagementView;
    private ManagementView managementView;

    public ProductManagementController(ProductManagementView productManagementView, ManagementView managementView) {
        this.productManagementView = productManagementView;
        this.managementView = managementView;
        addListeners();
    }

    private void addListeners() {
        productManagementView.getAddButton().addActionListener(e ->addProduct());
        productManagementView.getEditButton().addActionListener(e ->editProduct());
        productManagementView.getDeleteButton().addActionListener(e ->deleteProduct());
        productManagementView.getBackButton().addActionListener(e ->navigateBack());
    }

    public void navigateBack() {
        productManagementView.setVisible(false);
        managementView.setVisible(true);
    }

    private void addProduct() {
        String name = productManagementView.nameTextField.getText();
        String priceText = productManagementView.priceTextField.getText();
        String stockText = productManagementView.stockTextField.getText();

        if (name.isEmpty() || priceText.isEmpty() || stockText.isEmpty()) {
            JOptionPane.showMessageDialog(productManagementView, "All fields must be filled", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double price = Double.parseDouble(productManagementView.priceTextField.getText());
        int stock = Integer.parseInt(productManagementView.stockTextField.getText());

        try {
            Product product = new Product(0, name, price, stock);
            ProductBLL productBLL = new ProductBLL();
            productBLL.insertProduct(product);
            productManagementView.refreshProductTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(productManagementView, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editProduct() {
        int selectedRow = productManagementView.getProductTable().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(productManagementView, "Please select a product to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        DefaultTableModel model = (DefaultTableModel) productManagementView.getProductTable().getModel();
        int productId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());

        try {
            ProductBLL productBLL = new ProductBLL();
            Product existingProduct = productBLL.findProductById(productId);

            String name = productManagementView.nameTextField.getText();
            String priceText = productManagementView.priceTextField.getText();
            String stockText = productManagementView.stockTextField.getText();

            if (name.isEmpty() || priceText.isEmpty() || stockText.isEmpty()) {
                JOptionPane.showMessageDialog(productManagementView, "All fields must be filled", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double price = Double.parseDouble(productManagementView.priceTextField.getText());
            int stock = Integer.parseInt(productManagementView.stockTextField.getText());

            if (name != null && priceText != null && stockText != null) {
                existingProduct.setName(name);
                existingProduct.setPrice(price);
                existingProduct.setStock(stock);
                productBLL.updateProduct(existingProduct);
                productManagementView.refreshProductTable();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(productManagementView, "Failed to update product: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteProduct() {
        int selectedRow = productManagementView.getProductTable().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(productManagementView, "Please select a product to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        DefaultTableModel model = (DefaultTableModel) productManagementView.getProductTable().getModel();
        int productId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());

        int confirm = JOptionPane.showConfirmDialog(productManagementView, "Are you sure you want to delete this product?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                ProductBLL productBLL = new ProductBLL();
                productBLL.deleteProduct(new Product(productId, "", 0, 0));
                productManagementView.refreshProductTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(productManagementView, "Failed to delete product: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}

