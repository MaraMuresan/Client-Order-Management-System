package org.example.presentation.views;

import org.example.bll.BillBLL;
import org.example.model.Bill;
import org.example.presentation.ReflectionTableBuilder;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

/**
 * The {@code BillsManagementView} class is responsible for displaying the bills log in a graphical user interface.
 * This view includes functionality to refresh the table of bills dynamically and handles user interactions
 * related to bill management.
 *
 * This class extends {@link JFrame} and utilizes {@link ReflectionTableBuilder} to create a table from a list of {@link Bill} objects.
 */

public class BillsManagementView extends JFrame {

    private JLabel titleLabel;
    private JTable billsTable;
    private JScrollPane scrollPane;

    public BillsManagementView(List<Bill> bills) {

        setTitle("Bills LOG");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(200, 15, 600, 630);
        getContentPane().setBackground(new Color(255, 255, 133));
        setLayout(null);

        titleLabel = new JLabel("Bills LOG");
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 25));
        titleLabel.setForeground(new Color(137, 3, 142));
        titleLabel.setBounds(0, 15, 600, 30);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        billsTable = ReflectionTableBuilder.createTableFromObjects(bills);
        scrollPane = new JScrollPane(billsTable);
        scrollPane.setBounds(50, 70, 500, 500);
        add(scrollPane);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void setNewTable(JTable newTable) {
        remove(scrollPane);

        this.billsTable = newTable;
        this.scrollPane = new JScrollPane(newTable);

        scrollPane.setBounds(50, 70, 500, 500);
        add(scrollPane);

        validate();
        repaint();
    }

    public void refreshBillsTable() {
        SwingUtilities.invokeLater(() -> {
            try {
                BillBLL billBLL = new BillBLL();
                List<Bill> bills = billBLL.findAllBills();

                JTable newTable = ReflectionTableBuilder.createTableFromObjects(bills);

                setNewTable(newTable);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error refreshing bills table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public JTable getBillsTable() {
        return billsTable;
    }
}
