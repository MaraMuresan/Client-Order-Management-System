package org.example.presentation.views;

import org.example.bll.ClientBLL;
import org.example.model.Client;
import org.example.presentation.ReflectionTableBuilder;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

/**
 * The {@code ClientManagementView} class provides a graphical user interface for managing client information.
 * It includes features to add, edit, and delete clients, as well as navigate back to previous views.
 * The view is capable of displaying a list of clients in a table format that can be refreshed dynamically.
 */

public class ClientManagementView extends JFrame {

    private JLabel titleLabel;
    private JLabel nameLabel;
    private JLabel addressLabel;
    private JLabel emailLabel;
    public JTextField nameTextField;
    public JTextField addressTextField;
    public JTextField emailTextField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton backButton;
    private JTable clientTable;
    private JScrollPane scrollPane;

    public ClientManagementView(List<Client> clients) {

        setTitle("Client Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(200, 15, 1300, 600);
        getContentPane().setBackground(new Color(255, 255, 133));
        setLayout(null);

        titleLabel = new JLabel("Client Management");
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 25));
        titleLabel.setForeground(new Color(137, 3, 142));
        titleLabel.setBounds(0, 15, 1300, 30);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        nameLabel.setForeground(new Color(137, 3, 142));
        nameLabel.setBounds(20, 100, 100, 30);
        nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(nameLabel);

        nameTextField = new JTextField(60);
        nameTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        nameTextField.setBounds(150, 100, 300, 30);
        nameTextField.setHorizontalAlignment(JTextField.CENTER);
        add(nameTextField);

        addressLabel = new JLabel("Address:");
        addressLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        addressLabel.setForeground(new Color(137, 3, 142));
        addressLabel.setBounds(20, 150, 100, 30);
        addressLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(addressLabel);

        addressTextField = new JTextField(60);
        addressTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        addressTextField.setBounds(150, 150, 300, 30);
        addressTextField.setHorizontalAlignment(JTextField.CENTER);
        add(addressTextField);

        emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        emailLabel.setForeground(new Color(137, 3, 142));
        emailLabel.setBounds(20, 200, 100, 30);
        emailLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(emailLabel);

        emailTextField = new JTextField(60);
        emailTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        emailTextField.setBounds(150, 200, 300, 30);
        emailTextField.setHorizontalAlignment(JTextField.CENTER);
        add(emailTextField);


        addButton = new JButton("Add Client");
        addButton.setBounds(75, 300, 300, 35);
        addButton.setFont(new Font("Georgia", Font.BOLD, 15));
        addButton.setForeground(new Color(137, 3, 142));
        add(addButton);

        editButton = new JButton("Edit Selected Client");
        editButton.setBounds(75, 350, 300, 35);
        editButton.setFont(new Font("Georgia", Font.BOLD, 15));
        editButton.setForeground(new Color(137, 3, 142));
        add(editButton);

        deleteButton = new JButton("Delete Selected Client");
        deleteButton.setBounds(75, 400, 300, 35);
        deleteButton.setFont(new Font("Georgia", Font.BOLD, 15));
        deleteButton.setForeground(new Color(137, 3, 142));
        add(deleteButton);

        backButton = new JButton("Back");
        backButton.setBounds(175, 500, 100, 35);
        backButton.setFont(new Font("Georgia", Font.BOLD, 15));
        backButton.setForeground(new Color(137, 3, 142));
        add(backButton);

        clientTable = ReflectionTableBuilder.createTableFromObjects(clients);
        scrollPane = new JScrollPane(clientTable);
        scrollPane.setBounds(550, 100, 700, 435);
        add(scrollPane);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void setNewTable(JTable newTable) {
        remove(scrollPane);

        this.clientTable = newTable;
        this.scrollPane = new JScrollPane(newTable);

        scrollPane.setBounds(550, 100, 700, 435);
        add(scrollPane);

        validate();
        repaint();
    }

    public void refreshClientTable() {
        SwingUtilities.invokeLater(() -> {
            try {
                ClientBLL clientBLL = new ClientBLL();
                List<Client> clients = clientBLL.findAllClients();
                JTable newTable = ReflectionTableBuilder.createTableFromObjects(clients);

                setNewTable(newTable);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error refreshing client table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getBackButton() {
        return backButton;
    }

    public JTable getClientTable() {
        return clientTable;
    }
}
