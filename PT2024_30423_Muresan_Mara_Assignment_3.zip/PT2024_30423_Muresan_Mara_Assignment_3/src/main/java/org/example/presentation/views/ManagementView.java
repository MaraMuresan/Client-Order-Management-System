package org.example.presentation.views;

import javax.swing.*;
import java.awt.*;

/**
 * The {@code ManagementView} class provides a graphical user interface for managing different aspects of the application.
 * It includes buttons for navigating to client, product, and order management views.
 * This class is designed to serve as the main menu for management options.
 */

public class ManagementView extends JFrame {

    private JButton clientManagementButton;
    private JButton productManagementButton;
    private JButton orderManagementButton;

    public ManagementView() {
        initializeUI();
    }

    private void initializeUI() {

        setTitle("Management Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(255, 255, 133));
        setBounds(200, 15, 500, 400);
        setLayout(null);

        clientManagementButton = new JButton("Client Management");
        clientManagementButton.setBounds(125, 50, 250, 50);
        clientManagementButton.setFont(new Font("Georgia", Font.BOLD, 15));
        clientManagementButton.setForeground(new Color(137, 3, 142));
        add(clientManagementButton);

        productManagementButton = new JButton("Product Management");
        productManagementButton.setBounds(125, 150, 250, 50);
        productManagementButton.setFont(new Font("Georgia", Font.BOLD, 15));
        productManagementButton.setForeground(new Color(137, 3, 142));
        add(productManagementButton);

        orderManagementButton = new JButton("Order Management");
        orderManagementButton.setBounds(125, 250, 250, 50);
        orderManagementButton.setFont(new Font("Georgia", Font.BOLD, 15));
        orderManagementButton.setForeground(new Color(137, 3, 142));
        add(orderManagementButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public JButton getClientManagementButton() {
        return clientManagementButton;
    }

    public JButton getProductManagementButton() {
        return productManagementButton;
    }

    public JButton getOrderManagementButton() {
        return orderManagementButton;
    }
}
