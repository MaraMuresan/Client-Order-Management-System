package org.example.presentation.views;

import org.example.bll.OrderBLL;
import org.example.model.Client;
import org.example.model.Orderr;
import org.example.model.Product;
import org.example.presentation.ReflectionTableBuilder;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

/**
 * The {@code OrderManagementView} class provides a graphical user interface for placing and managing orders.
 * It displays orders, clients, and products in a table and allows for operations such as placing a new order
 * and refreshing the table to see updated data. This view supports selecting clients and products from dropdown
 * menus and specifying the quantity for new orders.
 */

public class OrderManagementView extends JFrame {

    private JLabel titleLabel;
    private JLabel idClientLabel;
    private JLabel idProductLabel;
    private JLabel quantityLabel;
    public JComboBox<String> clientComboBox;
    public JComboBox<String> productComboBox;
    public JTextField quantityTextField;
    private JButton placeOrderButton;
    private JButton backButton;
    private JTable orderTable;
    private JScrollPane scrollPane;

    public OrderManagementView(List<Orderr> orders, List<Client> clients, List<Product> products) {

        setTitle("Order Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(200, 15, 1300, 600);
        getContentPane().setBackground(new Color(255, 255, 133));
        setLayout(null);

        titleLabel = new JLabel("Order Management");
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 25));
        titleLabel.setForeground(new Color(137, 3, 142));
        titleLabel.setBounds(0, 15, 1300, 30);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        idClientLabel = new JLabel("Client ID:");
        idClientLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        idClientLabel.setForeground(new Color(137, 3, 142));
        idClientLabel.setBounds(20, 100, 100, 30);
        idClientLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(idClientLabel);

        clientComboBox = new JComboBox<>();
        for (Client client : clients) {
            clientComboBox.addItem(client.getId() + " - " + client.getName());
        }
        clientComboBox.setBounds(150, 100, 300, 30);
        add(clientComboBox);

        idProductLabel = new JLabel("Product ID:");
        idProductLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        idProductLabel.setForeground(new Color(137, 3, 142));
        idProductLabel.setBounds(20, 150, 100, 30);
        idProductLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(idProductLabel);

        productComboBox = new JComboBox<>();
        for (Product product : products) {
            productComboBox.addItem(product.getId() + " - " + product.getName());
        }
        productComboBox.setBounds(150, 150, 300, 30);
        add(productComboBox);

        quantityLabel = new JLabel("Quantity:");
        quantityLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        quantityLabel.setForeground(new Color(137, 3, 142));
        quantityLabel.setBounds(20, 200, 100, 30);
        quantityLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(quantityLabel);

        quantityTextField = new JTextField(60);
        quantityTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        quantityTextField.setBounds(150, 200, 300, 30);
        quantityTextField.setHorizontalAlignment(JTextField.CENTER);
        add(quantityTextField);


        placeOrderButton = new JButton("Place the order");
        placeOrderButton.setBounds(75, 300, 300, 50);
        placeOrderButton.setFont(new Font("Georgia", Font.BOLD, 15));
        placeOrderButton.setForeground(new Color(137, 3, 142));
        add(placeOrderButton);


        backButton = new JButton("Back");
        backButton.setBounds(175, 500, 100, 35);
        backButton.setFont(new Font("Georgia", Font.BOLD, 15));
        backButton.setForeground(new Color(137, 3, 142));
        add(backButton);


        orderTable = ReflectionTableBuilder.createTableFromObjects(orders);
        scrollPane = new JScrollPane(orderTable);
        scrollPane.setBounds(550, 100, 700, 435);
        add(scrollPane);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void setNewTable(JTable newTable) {
        remove(scrollPane);

        this.orderTable = newTable;
        this.scrollPane = new JScrollPane(newTable);

        scrollPane.setBounds(550, 100, 700, 435);
        add(scrollPane);

        validate();
        repaint();
    }

    public void refreshOrderTable() {
        SwingUtilities.invokeLater(() -> {
            try {
                OrderBLL orderBLL = new OrderBLL();
                List<Orderr> orders = orderBLL.findAllOrders();

                JTable newTable = ReflectionTableBuilder.createTableFromObjects(orders);

                setNewTable(newTable);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error refreshing order table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public JButton getPlaceOrderButton() {
        return placeOrderButton;
    }

    public JButton getBackButton() {
        return backButton;
    }

    public JTable getOrderTable() {
        return orderTable;
    }
}
