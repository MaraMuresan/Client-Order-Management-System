package org.example.presentation.views;

import org.example.bll.ProductBLL;
import org.example.model.Product;
import org.example.presentation.ReflectionTableBuilder;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

/**
 * The {@code ProductManagementView} class provides a graphical user interface for managing product details.
 * It allows adding, editing, and deleting products, as well as refreshing the displayed product list.
 * This class handles user interactions and updates the product list based on actions performed.
 */

public class ProductManagementView extends JFrame {

    private JLabel titleLabel;
    private JLabel nameLabel;
    private JLabel priceLabel;
    private JLabel stockLabel;
    public JTextField nameTextField;
    public JTextField priceTextField;
    public JTextField stockTextField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton backButton;
    private JTable productTable;
    private JScrollPane scrollPane;

    public ProductManagementView(List<Product> products) {

        setTitle("Product Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(200, 15, 1300, 600);
        getContentPane().setBackground(new Color(255, 255, 133));
        setLayout(null);

        titleLabel = new JLabel("Product Management");
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 25));
        titleLabel.setForeground(new Color(137, 3, 142));
        titleLabel.setBounds(0, 15, 1300, 30);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel);

        nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        nameLabel.setForeground(new Color(137, 3, 142));
        nameLabel.setBounds(20, 100, 100, 30);
        nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(nameLabel);

        nameTextField = new JTextField(60);
        nameTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        nameTextField.setBounds(150, 100, 300, 30);
        nameTextField.setHorizontalAlignment(JTextField.CENTER);
        add(nameTextField);

        priceLabel = new JLabel("Price:");
        priceLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        priceLabel.setForeground(new Color(137, 3, 142));
        priceLabel.setBounds(20, 150, 100, 30);
        priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(priceLabel);

        priceTextField = new JTextField(60);
        priceTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        priceTextField.setBounds(150, 150, 300, 30);
        priceTextField.setHorizontalAlignment(JTextField.CENTER);
        add(priceTextField);

        stockLabel = new JLabel("Stock:");
        stockLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        stockLabel.setForeground(new Color(137, 3, 142));
        stockLabel.setBounds(20, 200, 100, 30);
        stockLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(stockLabel);

        stockTextField = new JTextField(60);
        stockTextField.setFont(new Font("Georgia", Font.BOLD, 15));
        stockTextField.setBounds(150, 200, 300, 30);
        stockTextField.setHorizontalAlignment(JTextField.CENTER);
        add(stockTextField);


        addButton = new JButton("Add Product");
        addButton.setBounds(75, 300, 300, 35);
        addButton.setFont(new Font("Georgia", Font.BOLD, 15));
        addButton.setForeground(new Color(137, 3, 142));
        add(addButton);

        editButton = new JButton("Edit Selected Product");
        editButton.setBounds(75, 350, 300, 35);
        editButton.setFont(new Font("Georgia", Font.BOLD, 15));
        editButton.setForeground(new Color(137, 3, 142));
        add(editButton);

        deleteButton = new JButton("Delete Selected Product");
        deleteButton.setBounds(75, 400, 300, 35);
        deleteButton.setFont(new Font("Georgia", Font.BOLD, 15));
        deleteButton.setForeground(new Color(137, 3, 142));
        add(deleteButton);

        backButton = new JButton("Back");
        backButton.setBounds(175, 500, 100, 35);
        backButton.setFont(new Font("Georgia", Font.BOLD, 15));
        backButton.setForeground(new Color(137, 3, 142));
        add(backButton);

        productTable = ReflectionTableBuilder.createTableFromObjects(products);
        scrollPane = new JScrollPane(productTable);
        scrollPane.setBounds(550, 100, 700, 435);
        add(scrollPane);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void setNewTable(JTable newTable) {
        remove(scrollPane);

        this.productTable = newTable;
        this.scrollPane = new JScrollPane(newTable);

        scrollPane.setBounds(550, 100, 700, 435);
        add(scrollPane);

        validate();
        repaint();
    }

    public void refreshProductTable() {
        SwingUtilities.invokeLater(() -> {
            try {
                ProductBLL productBLL = new ProductBLL();
                List<Product> products = productBLL.findAllProducts();

                JTable newTable = ReflectionTableBuilder.createTableFromObjects(products);


                setNewTable(newTable);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error refreshing product table: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public JButton getAddButton() {
        return addButton;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JButton getBackButton() {
        return backButton;
    }

    public JTable getProductTable() {
        return productTable;
    }
}
